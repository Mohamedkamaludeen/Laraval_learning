
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<center>
<h2>LogIn</h2>
<form action = "post">
    email    <input type = "email" name = "email" placeholder = "email" size = "50"><br><br>
    password <input type = "password" name = "password" placeholder = "password" size = "50"  maxlength="8" ><br><br>
    <button>Login</button>
</form>
</center>
</body>
</html><?php /**PATH C:\Users\E-Lab User\Desktop\HelloApp\resources\views/user.blade.php ENDPATH**/ ?>