<h1>hai i am luxshika prashath</h1>
<?php echo e($msg); ?><?php /**PATH C:\Users\E-Lab User\Desktop\HelloApp\resources\views/hello.blade.php ENDPATH**/ ?>