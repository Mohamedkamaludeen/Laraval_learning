<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body >
        <h1> welcome to first laravel project</h1>

                    
    </body>
</html>
<?php /**PATH C:\Users\E-Lab Staff\Desktop\2019csc030\2019csc030\HelloApp\resources\views/welcome.blade.php ENDPATH**/ ?>